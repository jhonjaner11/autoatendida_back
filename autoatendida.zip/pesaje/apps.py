from django.apps import AppConfig


class PesajeConfig(AppConfig):
    name = 'pesaje'
